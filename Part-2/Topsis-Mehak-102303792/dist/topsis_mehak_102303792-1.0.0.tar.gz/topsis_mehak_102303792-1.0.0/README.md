# Topsis-Mehak-102303792

Python package implementing TOPSIS method.

## Installation
pip install Topsis-Mehak-102303792

## Usage
topsis input.xlsx "1,1,1,1,1" "+,+,-,+,+" result.csv

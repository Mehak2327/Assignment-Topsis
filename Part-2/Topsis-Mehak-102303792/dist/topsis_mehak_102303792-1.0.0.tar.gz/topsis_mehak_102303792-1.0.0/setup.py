from setuptools import setup, find_packages

setup(
    name="Topsis-Mehak-102303792",
    version="1.0.0",
    packages=find_packages(),
    install_requires=["pandas","numpy","openpyxl"],
    entry_points={
        "console_scripts": [
            "topsis=topsis_mehak.topsis:topsis"
        ]
    }
)
